import React from 'react';
import './style.css'
import { useDispatch, useSelector } from 'react-redux';
import { MainInterface, StepInterface } from '../../redux/types';
import { onChangeStep, onFinishStep } from '../../redux/actions/index'


const Header = () => {

  const staps = useSelector((state: MainInterface) => state.steps)
  const dispatch = useDispatch()


  const handleChangeStep = (arg: string) => {
    const obj: StepInterface = {
      key: arg
    }
    dispatch(onChangeStep(obj))
  }

 

  return (
    <nav className='nav-wrapper' >
      <div className='nav-title' >
        <h1>Checkout Form</h1>
      </div>
      <div className="stepper-wrapper">
        <div className="stepper-line">

          <div
            className={`stepper-item${staps?.details ? "-active" : ""}`}
            onClick={() => handleChangeStep("details")}
          >
            Details
          </div>
          <div
            className={`stepper-item${staps?.shipping ? "-active" : ""}`}
            onClick={() => handleChangeStep("shipping")}
          >
            Shipping
          </div>
          <div
            className={`stepper-item${staps?.payment ? "-active" : ""}`}
            onClick={() => handleChangeStep("payment")}
          >
            Payment
          </div>
        </div>

      </div>
    </nav>
  )
}

export default Header;