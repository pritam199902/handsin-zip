import React from 'react'

const Finish = () => {
  return (
    <div>
        <img src="/pay-done.png" alt="" height='100' style={{padding: '10px', margin: '20px'}} />
    </div>
  )
}

export default Finish