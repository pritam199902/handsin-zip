import React from 'react'
// import './style.css'
const Input = (props: any) => {
    return (
        <>
            <div className='input-container' >
                <div className='input-label' >{props?.label}</div>
                <input
                    className='input'
                    {...props}
                />
            </div>
        </>
    )
}

export default Input