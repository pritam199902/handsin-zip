import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { onChangeStep, onFinishStep, onPaymentChangeText } from '../../../redux/actions'
import { FormInterface, MainInterface, StepInterface } from '../../../redux/types'
import Input from '../../inputs/Input'

const PaymentForm = () => {
    const forms = useSelector((state: MainInterface) => state.forms)

    const payment = useSelector((state: MainInterface) => state.forms.payment)
    const dispatch = useDispatch()

    const handleOnChangeText = (e: any) => {
        const key: string = e?.target?.name
        const value: string = e?.target?.value

        const obj: FormInterface = {
            key: key,
            value: value
        }
        dispatch(onPaymentChangeText(obj))
    }


    const handleChangeStep = (arg: string) => {
        const obj: StepInterface = {
            key: arg
        }
        dispatch(onChangeStep(obj))
    }


    const handleFinishStep = () => {
        console.log(forms);

        dispatch(onFinishStep())
    }

    const [isDisabled, setIsDisabled] = React.useState(true)
    React.useEffect(() => {
        let mount = true
        if (
            payment?.nameOnCard.length > 0 && payment?.cardNo.length > 0 && payment?.cvv.length > 0 && payment?.expDate.length > 0
        ) {
            mount && setIsDisabled(false)
        } else {
            mount && setIsDisabled(true)
        }

        return () => {
            mount = false
        }
    }, [payment])


    return (
        <>
            <div className="form-wrapper">
                <h3 className='form-title' >Shipping Form</h3>
                <form className='flex' >
                    <Input type="text" name="nameOnCard" placeholder="MR J APPLESEED" label="Name on Card" value={payment?.nameOnCard} onChange={handleOnChangeText} />
                    <Input type="text" name="cardNo" placeholder="8888 8888 8888 8888" label="Card Number" value={payment?.cardNo} onChange={handleOnChangeText} />
                    <div className="flex-row input-container ">
                        <Input type="password" name="cvv" placeholder="000" label="CVV" style={{ width: "60%" }} value={payment?.cvv} onChange={handleOnChangeText} />
                        <Input type="text" name="expDate" placeholder="00/00" label="Expiration Date" style={{ width: "100%" }} value={payment?.expDate} onChange={handleOnChangeText} />
                    </div>

                    <div className='flex-row' >
                        <button type="submit" className='back-btn' onClick={() => handleChangeStep("shipping")}>Go back</button>
                        <button type="submit" disabled={isDisabled} className={`next-btn${isDisabled ? "-disabled" : ''}`} onClick={() => handleFinishStep()}>Submit</button>
                    </div>
                </form>
            </div>

        </>
    )
}

export default PaymentForm