import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { MainInterface, FormInterface, StepInterface } from '../../../redux/types';
import { onChangeStep, onDetailsChangeText } from '../../../redux/actions/index'

import Input from '../../inputs/Input'

const DetailsForm = () => {

    const details = useSelector((state: MainInterface) => state.forms.details)
    const dispatch = useDispatch()

    const handleOnChangeText = (e: any) => {
        const key: string = e?.target?.name
        const value: string = e?.target?.value

        const obj: FormInterface = {
            key: key,
            value: value
        }
        dispatch(onDetailsChangeText(obj))
    }


    const handleChangeStep = (arg: string) => {
        const obj: StepInterface = {
            key: arg
        }
        dispatch(onChangeStep(obj))
    }

    const [isDisabled, setIsDisabled] = React.useState(true)
    useEffect(() => {
        let mount = true
        if (
            details?.email.length > 0 && details?.firstName.length > 0 && details?.lastName.length > 0 && details?.mobile.length > 0
        ) {
            mount && setIsDisabled(false)
        } else {
            mount && setIsDisabled(true)
        }

        return () => {
            mount = false
        }
    }, [details])


    return (
        <>
            <div className="form-wrapper">
                <h3 className='form-title' >Details Form</h3>
                <form className='flex' >
                    <Input type="text" name="firstName" placeholder="John" label="First Name" value={details?.firstName} onChange={handleOnChangeText} />
                    <Input type="text" name="lastName" placeholder="Appleseed" label="Last Name" value={details?.lastName} onChange={handleOnChangeText} />
                    <Input type="text" name="email" placeholder="johnappleseed@gmail.com" label="Email" value={details?.email} onChange={handleOnChangeText} />
                    <Input type="text" name="mobile" placeholder="0123456789" label="Mobile Number" value={details?.mobile} onChange={handleOnChangeText} />
                    <button type="submit" disabled={isDisabled} className={`next-btn${isDisabled ? "-disabled" : ''}`} onClick={() => handleChangeStep("shipping")} >Go to Shipping</button>
                </form>
            </div>
        </>
    )
}

export default DetailsForm