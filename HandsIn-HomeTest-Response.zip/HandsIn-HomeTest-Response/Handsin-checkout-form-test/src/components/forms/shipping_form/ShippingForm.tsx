import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { onChangeStep, onShippingChangeText } from '../../../redux/actions'
import { FormInterface, MainInterface, StepInterface } from '../../../redux/types'
import Input from '../../inputs/Input'

const ShippingForm = () => {
    const shipping = useSelector((state: MainInterface) => state.forms.shipping)
    const dispatch = useDispatch()

    const handleOnChangeText = (e: any) => {
        const key: string = e?.target?.name
        const value: string = e?.target?.value

        const obj: FormInterface = {
            key: key,
            value: value
        }
        dispatch(onShippingChangeText(obj))
    }


    const handleChangeStep = (arg: string) => {
        const obj: StepInterface = {
            key: arg
        }
        dispatch(onChangeStep(obj))
    }


    const [isDisabled, setIsDisabled] = React.useState(true)
    React.useEffect(() => {
        let mount = true
        if (
            shipping?.address.length > 0 && shipping?.city.length > 0 && shipping?.zip.length > 0 && shipping?.state.length > 0 && shipping?.country.length > 0
        ) {
            mount && setIsDisabled(false)
        }else {
            mount && setIsDisabled(true)
        }

        return () => {
            mount = false
        }
    }, [shipping])
    return (
        <>
            <div className="form-wrapper">
                <h3 className='form-title' >Shipping Form</h3>
                <form className='flex' >
                    <Input type="text" name="address" placeholder="1 brick lane" label="Address" value={shipping?.address} onChange={handleOnChangeText} />
                    <Input type="text" name="city" placeholder="London" label="City" value={shipping?.city} onChange={handleOnChangeText} />
                    <Input type="text" name="zip" placeholder="CEA 4SA" label="Zip code" value={shipping?.zip} onChange={handleOnChangeText} />
                    <Input type="text" name="state" placeholder="England" label="State/Province" value={shipping?.state} onChange={handleOnChangeText} />
                    <Input type="text" name="country" placeholder="United Kingdom" label="Country" value={shipping?.country} onChange={handleOnChangeText} />

                    <div className='flex-row' >
                        <button type="submit" className='back-btn' onClick={() => handleChangeStep("details")} >Go back</button>
                        <button type="submit" disabled={isDisabled} className={`next-btn${isDisabled ? "-disabled" : ''}`} onClick={() => handleChangeStep("payment")} >Go to Payment</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default ShippingForm