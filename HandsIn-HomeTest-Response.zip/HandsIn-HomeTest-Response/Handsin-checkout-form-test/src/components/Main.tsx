import React from 'react';
import './style.css'

import { useDispatch, useSelector } from 'react-redux';
import { MainInterface, StepInterface } from '../redux/types';
import { onChangeStep } from '../redux/actions/index'

import DetailsForm from './forms/details_form/DetailsForm';
import PaymentForm from './forms/payment_form/PaymentForm';
import ShippingForm from './forms/shipping_form/ShippingForm';
import Finish from './Finish';


const Main = () => {

  const state = useSelector((state: MainInterface) => state)
  const dispatch = useDispatch()
  return (
    <>
      <div className="main-wrapper">
        {
          state?.is_finish ?
            <Finish />
            :
            <>
              {state?.steps?.details && <DetailsForm />}
              {state?.steps?.shipping && <ShippingForm />}
              {state?.steps?.payment && <PaymentForm />}
            </>
        }

      </div>
    </>
  )
}

export default Main;