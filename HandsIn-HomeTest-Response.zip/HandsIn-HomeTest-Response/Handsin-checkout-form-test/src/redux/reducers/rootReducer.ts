import * as actionType from '../types/index'


const initialState: actionType.MainInterface = {
  steps: {
    details: true,
    shipping: false,
    payment: false
  },
  forms: {
    details: {
      firstName: '',
      lastName: '',
      email: '',
      mobile: ''
    },
    shipping: {
      address: '',
      city: '',
      zip: '',
      state: '',
      country: ''
    },
    payment: {
      nameOnCard: '',
      cardNo: '',
      cvv: '',
      expDate: ''
    }
  },
  is_finish: false
}





const rootReducer = (state: actionType.MainInterface = initialState, action: any) => {
  switch (action.type) {

    case actionType.Types.SET_STEP:
      if (!state?.is_finish) {
        return { ...state, steps: { details: action?.payload?.key === "details", shipping: action?.payload?.key === "shipping", payment: action?.payload?.key === "payment" } }
      }
      return { ...state }

    case actionType.Types.FINISH:
      return { ...state, is_finish: true }

    case actionType.Types.DETAILS_TEXT_CHANGE:
      return {
        ...state,
        forms: {
          ...state?.forms,
          details: {
            ...state?.forms?.details,
            [`${action?.payload?.key}`]: action?.payload?.value
          }
        }
      }

    case actionType.Types.SHIPPING_TEXT_CHANGE:

      return {
        ...state,
        forms: {
          ...state?.forms,
          shipping: {
            ...state?.forms?.shipping,
            [`${action?.payload?.key}`]: action?.payload?.value
          }
        }
      }

    case actionType.Types.PAYMENT_TEXT_CHANGE:

      return {
        ...state,
        forms: {
          ...state?.forms,
          payment: {
            ...state?.forms?.payment,
            [`${action?.payload?.key}`]: action?.payload?.value
          }
        }
      }


    default:
      return state;
  }
}




export default rootReducer;