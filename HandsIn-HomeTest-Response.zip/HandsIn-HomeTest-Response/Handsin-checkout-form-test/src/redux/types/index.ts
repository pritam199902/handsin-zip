export enum Types {
    SET_STEP = 'SET_STEP',
    FINISH = 'FINISH',

    DETAILS_TEXT_CHANGE = "DETAILS_TEXT_CHANGE",
    SHIPPING_TEXT_CHANGE = "SHIPPING_TEXT_CHANGE",
    PAYMENT_TEXT_CHANGE = "PAYMENT_TEXT_CHANGE",

}




export interface MainInterface {
    steps: {
        details: boolean,
        shipping: boolean,
        payment: boolean
    },
    forms: {
        details: {
            firstName: string,
            lastName: string,
            email: string,
            mobile: string
        },
        shipping: {
            address: string,
            city: string,
            zip: string,
            state: string,
            country: string
        },
        payment: {
            nameOnCard: string,
            cardNo: string,
            cvv: string,
            expDate: string
        }
    },
    is_finish: boolean
}



// type GlobalState = {
//     data: MainInterface
// }




export interface StepInterface {
    key: string,
    // value: boolean
}

export interface FormInterface {
    key: string,
    value: string
}

export type StepAction = {
    type: string,
    payload: StepInterface
}

export type FormAction = {
    type: string,
    payload: FormInterface
}

export type StepDispatchType = (args: StepAction) => StepAction
export type FormDispatchType = (args: FormAction) => FormAction
