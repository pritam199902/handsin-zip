import { MainInterface, StepInterface, Types } from './../types/index';

import * as actionTypes from '../types/index'

export function onChangeStep(data: StepInterface) {
  const action: actionTypes.StepAction = {
    type: Types.SET_STEP,
    payload: data,
  }
  return changeStepHandler(action)
}

export function onFinishStep() {
  const action: any = {
    type: Types.FINISH,
  }
  return changeStepHandler(action)
}

export function changeStepHandler(action: actionTypes.StepAction) {
  return (dispatch: actionTypes.StepDispatchType) => {
    // setTimeout(() => {
    dispatch(action)
    // }, 500)
  }
}





export function onDetailsChangeText(data: actionTypes.FormInterface) {
  const action: actionTypes.FormAction = {
    type: Types.DETAILS_TEXT_CHANGE,
    payload: data,
  }
  return changeTextHandler(action)
}

export function onShippingChangeText(data: actionTypes.FormInterface) {
  const action: actionTypes.FormAction = {
    type: Types.SHIPPING_TEXT_CHANGE,
    payload: data,
  }
  return changeTextHandler(action)
}


export function onPaymentChangeText(data: actionTypes.FormInterface) {
  const action: actionTypes.FormAction = {
    type: Types.PAYMENT_TEXT_CHANGE,
    payload: data,
  }
  return changeTextHandler(action)
}



export function changeTextHandler(action: actionTypes.FormAction) {
  return (dispatch: actionTypes.FormDispatchType) => {
    // setTimeout(() => {
    dispatch(action)
    // }, 500)
  }
}
