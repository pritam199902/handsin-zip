

import 'mocha'
import assert from 'assert'
import { Weather, DefaultWeatherPredictorService } from '../src/services/WeatherPredictorService'


describe('GET WEATHER', function () {


    describe('#getWeather(date:Date)', function () {
        it('should return Predicted Weather(4=>SHOW) without error', function (done) {
            const WObj = new DefaultWeatherPredictorService()
            const input_date = new Date(1644725305883)
            const res = WObj.getWeather(input_date)

            if (res === 4) {
                done()
            } else done(new Error("Not found"))

        });
    });




    describe('#updateWeather(date:Date, weather:Weather)', function () {
        it('should update Weather from SNOW to SUNNY without error', function (done) {
            const date_input = new Date(1644725305883)
            const weather_input = Weather["SUNNY"]
            const output_should = 0
            const WObj = new DefaultWeatherPredictorService()


            WObj.updateWeather(date_input, weather_input)

            const input_date = new Date(date_input)
            const res = WObj.getWeather(input_date)
            if (res === output_should) {
                done()
            } else done(new Error("Not found"))
        });
    });
});