export enum Weather {
	SUNNY, RAINY, CLOUDY, HAIL, SNOW
}

const PREDIC_LIST = [
	{
		index: 0,
		month: "January",
		weather: Weather.SNOW
	},
	{
		index: 1,
		month: "February",
		weather: Weather.SNOW
	},
	{
		index: 2,
		month: "March",
		weather: Weather.RAINY
	},
	{
		index: 3,
		month: "April",
		weather: Weather.RAINY
	},
	{
		index: 4,
		month: "May",
		weather: Weather.CLOUDY
	},
	{
		index: 5,
		month: "June",
		weather: Weather.SUNNY
	},
	{
		index: 6,
		month: "July",
		weather: Weather.SUNNY
	},
	{
		index: 7,
		month: "August",
		weather: Weather.CLOUDY
	},
	{
		index: 8,
		month: "September",
		weather: Weather.CLOUDY
	},
	{
		index: 9,
		month: "October",
		weather: Weather.CLOUDY
	},
	{
		index: 10,
		month: "November",
		weather: Weather.HAIL
	},
	{
		index: 11,
		month: "December",
		weather: Weather.SNOW
	},
]


export interface WeatherPredictorService {
	getWeather(date: Date): Weather;
	updateWeather(date: Date, weather: Weather): void;
}


export class DefaultWeatherPredictorService implements WeatherPredictorService {

	// GET Weather
	public getWeather(date: Date): Weather {
		const monthIndex: number = this.getMonthIndexByDate(date)
		const predicted_weather: Weather = this.getPredictedWeather(monthIndex)
		return predicted_weather
	}

	private getPredictedWeather(index: number): Weather {
		const res_list = PREDIC_LIST?.filter(info => info?.index === index)
		const res: Weather = res_list[0].weather
		return res;
	}

	private getMonthIndexByDate(date: Date): number {
		// const month: string = date.toLocaleString('default', { month: 'long' });
		const res: number = date.getMonth()
		return res;
	}

	public getWeatherString(index: number): string {
		return Weather[index]
	}


	// UPDATE Weather
	public updateWeather(date: Date, weather: Weather): void {
		if (typeof date === 'undefined' || typeof weather === 'undefined') {
			throw new Error("Input not valid")
		}

		const is_updated = this.writeUpdate(this.getMonthIndexByDate(date), weather)
		if (!is_updated) {
			throw new Error("Fail to update!")
		}
	}


	private writeUpdate(monthIndex: number, weather: Weather): boolean {
		var is_updated: boolean = false

		PREDIC_LIST?.map?.(info => {
			if (info?.index === monthIndex) {
				info.weather = weather
				is_updated = true
			}
			return info
		})
		return is_updated;
	}



}