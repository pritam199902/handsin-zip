import express from 'express';
// import bodyParser from 'body-parser';

const app = express();
app.use(express.json());

import { Weather, DefaultWeatherPredictorService } from './services/WeatherPredictorService'

app.get('/predict', async (req, res) => {

    try {
        if (!req?.query?.date) {
            return res.status(422).send("Unable to process")
        }
        const date_arg: string = req.query.date as string;
        const date: Date = new Date(parseInt(date_arg))
        const WeatherObj = new DefaultWeatherPredictorService()
        const predicted_result: Weather = await WeatherObj.getWeather(date)
        return res.send(`${WeatherObj.getWeatherString(predicted_result)}`);
    } catch (error: any) {
        return res.status(400).send("Invalid input")
    }
})

app.post('/update', async (req, res) => {
    try {
        const date: string = req.body.date
        const weather: string = req.body.weather

        if (typeof date === 'undefined' || typeof weather === 'undefined') {
            return res.status(422).send("Unable to process")
        }
        const date_parse: Date = new Date(parseInt(date))
        const WeatherObj = new DefaultWeatherPredictorService()
        await WeatherObj.updateWeather(new Date(date_parse), Weather[`${weather?.toUpperCase?.()}`])
        return res.send()

    } catch (error: any) {
        return res.status(400).send(error?.message)
    }
})

app.listen(3000, () => {
    console.log('The application is listening on port 3000!');
})
